(() => {
  "use strict";

  async function loadJSON(url) {
    const response = await fetch(url, { cache: "default" });
    if (!response.ok) {
      throw new Error(`Failed to load ${url}: HTTP ${response.status}`);
    }
    return response.json();
  }

  function escapeHTML(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/\"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function openInNewTab(url) {
    const opened = window.open(url, "_blank", "noopener,noreferrer");
    if (opened) opened.opener = null;
  }

  function externalNetworkRequired(url) {
    return /^https?:\/\//i.test(String(url || "")) && !navigator.onLine;
  }

  function notifyOnlineFeature(feature = "This feature") {
    window.alert(`${feature} requires an internet connection. The Quran text, search, navigation, fonts, and morphology data remain available offline.`);
  }

  function installOfflineIndicator() {
    if (document.getElementById("offline-status")) return;
    const banner = document.createElement("div");
    banner.id = "offline-status";
    banner.setAttribute("role", "status");
    banner.setAttribute("aria-live", "polite");
    document.body.appendChild(banner);

    const update = () => {
      if (navigator.onLine) {
        banner.hidden = true;
        banner.textContent = "";
      } else {
        banner.hidden = false;
        banner.textContent = "Offline mode — Quran text, search, fonts and morphology are available. Audio and external manuscript links need internet.";
      }
    };

    window.addEventListener("online", update);
    window.addEventListener("offline", update);
    update();
  }

  window.QuranUtils = Object.freeze({
    loadJSON,
    escapeHTML,
    openInNewTab,
    externalNetworkRequired,
    notifyOnlineFeature,
  });

  document.addEventListener("DOMContentLoaded", installOfflineIndicator);
})();
